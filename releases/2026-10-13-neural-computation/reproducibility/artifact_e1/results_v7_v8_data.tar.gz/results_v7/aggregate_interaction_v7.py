"""聚合 B-1 交互量表：skeleton（del_skel/skel_only）× empty（删全部 HH）按 cell 配对。

输出 /home/lixuewei/tmp/struct_mod_v2/results_v7/interaction_table.csv
每行: cohort,task,tag,n_hh,J_F0,J_del_skel,J_skel_only,J_empty,
      dmg_skel,dmg_bg,dmg_empty,share_skel,share_bg,interaction
interaction I = J(F0) - J(S) - J(B) + J(empty)（=0 加性；>0 次加性/冗余；<0 超加性/协同）
share 以 dmg_empty（删全部 HH 的总损伤）归一。
"""
import csv
import json
from pathlib import Path

ROOT = Path("/home/lixuewei/tmp/struct_mod_v2")
V6, V7 = ROOT / "results_v6", ROOT / "results_v7"


def rows_for(skel_dir, pattern, cohort, task):
    for sp in sorted(skel_dir.glob(pattern)):
        d = json.load(open(sp))
        if cohort == "e1":
            tag = sp.stem.replace(f"skeleton_e1_{task}_", "")
            ep = V7 / "empty_lesion" / f"empty_v7_e1_{task}_{tag}.json"
        elif cohort == "main":
            tag = sp.stem.replace(f"skeleton_v6_{task}_", "")
            ep = V7 / "empty_lesion" / f"empty_v7_main_{task}_seed{tag}.json"
        else:
            tag = sp.stem.replace(f"skeleton_v6_{task}_", "")
            ep = V7 / "empty_lesion" / f"empty_v7_c2_{task}_seed{tag}.json"
        if not ep.exists():
            print(f"missing empty for {cohort} {task} {tag}")
            continue
        e = json.load(open(ep))
        c = d["conditions"]
        J_F0, J_S, J_B, J_E = (c["F0"]["return_mean"],
                               c["del_skel"]["return_mean"],
                               c["skel_only"]["return_mean"],
                               e["J_empty"])
        if abs(J_F0 - e["J_F0"]) > 1e-6:
            print(f"F0 mismatch {cohort} {task} {tag}: {J_F0} vs {e['J_F0']}")
            continue
        dmg_s, dmg_b, dmg_e = J_F0 - J_S, J_F0 - J_B, J_F0 - J_E
        inter = J_F0 - J_S - J_B + J_E
        yield {"cohort": cohort, "task": task, "tag": tag,
               "n_hh": d["n_hh"], "J_F0": J_F0, "J_del_skel": J_S,
               "J_skel_only": J_B, "J_empty": J_E,
               "dmg_skel": dmg_s, "dmg_bg": dmg_b, "dmg_empty": dmg_e,
               "share_skel": dmg_s / dmg_e if abs(dmg_e) > 1e-9 else None,
               "share_bg": dmg_b / dmg_e if abs(dmg_e) > 1e-9 else None,
               "interaction": inter,
               "interaction_norm": inter / dmg_e if abs(dmg_e) > 1e-9 else None}


def main():
    rows = []
    rows += list(rows_for(V6 / "skeleton_e1", "skeleton_e1_CartPole_*.json",
                          "e1", "CartPole"))
    for task in ("CartPole", "Acrobot"):
        rows += list(rows_for(V6 / "skeleton", f"skeleton_v6_{task}_*.json",
                              "main", task))
    rows += list(rows_for(V6 / "skeleton_c2", "skeleton_v6_CartPole_*.json",
                          "c2", "CartPole"))
    rows += list(rows_for(V6 / "skeleton_c2", "skeleton_v6_Acrobot_*.json",
                          "c2", "Acrobot"))
    out = V7 / "interaction_table.csv"
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"wrote {out}: {len(rows)} rows")
    from collections import Counter
    print(Counter((r["cohort"], r["task"]) for r in rows))


if __name__ == "__main__":
    main()
